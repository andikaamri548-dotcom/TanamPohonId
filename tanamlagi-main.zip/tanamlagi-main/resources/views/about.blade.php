@extends('layouts.main')

@section('container')
    <body>
        <div class="container-fluid justify-content-center">
            <h2>Tentang TanamLagi</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui mollitia quasi optio animi odit nam nostrum soluta recusandae harum assumenda dignissimos, ducimus eos explicabo, accusamus aliquid quaerat sint laboriosam vel.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis aspernatur doloremque quaerat obcaecati facere doloribus aliquid illum rerum accusantium impedit ducimus ipsum quia reprehenderit, repellendus mollitia nihil! Magni, nisi et.
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tempore dicta aperiam quisquam officiis excepturi et dolor, dolore corporis molestiae. Maxime dolores ratione, eveniet est error quibusdam. Exercitationem odio veniam rerum?
            </p>
        </div>
        <img src="/img/tanampohon.png" width="1280">
        <br>
        <br>
    </body>
@endsection